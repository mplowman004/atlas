# Atlas Lending — Live Utah County Data Setup

This build removes the seeded/demo Atlas API data and connects the dashboard to PostgreSQL-backed official-source ingestion.

## Official sources
- Utah County Assessor TaxParcel layer: `https://maps.utahcounty.gov/arcgis/rest/services/Pictometry/POL_Assr_TaxParcel/MapServer/0`
- Utah County Assessor Building Permits table: `https://maps200.utahcounty.gov/arcgis/rest/services/Assessor/Building_Permits/MapServer/1`

## First run in Replit
1. Confirm `DATABASE_URL` is provisioned in Replit.
2. In Shell: `pnpm --filter @workspace/db run push`
3. Start the Project workflow.
4. First QA run: use the API with `{ "limit": 100, "promoteVerified": false }` or temporarily change the dashboard button to false.
5. Review counts. Ambiguous/multi-parcel matches are held for review and are not written as opportunities.
6. Only after QA, run `{ "limit": 100, "promoteVerified": true }`.

## Integrity rules
- Source facts are stored with raw JSON and source URL.
- No fuzzy owner-name-only parcel matching.
- Permit `ACCOUNTNO` must resolve to exactly one parcel and exactly match the official `PARCELID`/`PARCEL_NO` after normalization.
- Owner-name agreement is corroboration, not the primary join.
- Product type, score, and estimated loan range are Atlas hypotheses and are explicitly described as such.
- Missing/ambiguous records are held or rejected; Atlas does not fill missing facts with guesses.

## Important
The prior dashboard displayed seeded sample companies and a simulated ingest result. Those were not live Utah County records. This build replaces that behavior with real database-backed ingestion.
