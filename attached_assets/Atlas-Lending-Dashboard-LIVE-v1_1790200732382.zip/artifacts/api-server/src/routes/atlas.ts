import { Router, type IRouter } from "express";
import { and, count, desc, eq, gte } from "drizzle-orm";
import { db, atlasIngestRuns, atlasOpportunities, atlasPermits, atlasProperties } from "@workspace/db";
import {
  GetAtlasDashboardResponse, ListAtlasFollowUpsResponse, ListAtlasOpportunitiesQueryParams,
  ListAtlasOpportunitiesResponse, ListAtlasReferralsResponse, ListAtlasSignalsResponse,
  RunAtlasIngestBody, RunAtlasIngestResponse,
} from "@workspace/api-zod";
import { atlasSources, exactAccountParcelMatch, fetchRecentPermits, findParcelForAccount, num, textValue, toDate } from "../services/utah-county";

const router: IRouter = Router();
const PROMOTION_THRESHOLD = 0.78;

function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }
function norm(s: string | null) { return (s ?? "").toUpperCase().replace(/[^A-Z0-9]/g, ""); }
function ownerCorroborates(a: string | null, b: string | null) {
  const x = norm(a), y = norm(b);
  return Boolean(x && y && (x === y || (x.length > 8 && y.length > 8 && (x.includes(y) || y.includes(x)))));
}
function isCommercial(a: Record<string, unknown>) {
  const t = `${a.PROP_TYPE_DESCR ?? ""} ${a.SPC_PROP_TYP_DESCR ?? ""}`.toUpperCase();
  return !/(RESIDENTIAL|SINGLE FAMILY|CONDO|TOWNHOME)/.test(t) && Boolean(t.trim());
}
function productHypothesis(permit: Record<string, unknown>, parcel: Record<string, unknown>) {
  const corpus = `${permit.PERMITTYPE ?? ""} ${permit.PERMITREASON ?? ""} ${permit.PERMITREASONDETAIL ?? ""} ${permit.PERMITUSE ?? ""} ${parcel.PROP_TYPE_DESCR ?? ""} ${parcel.SPC_PROP_TYP_DESCR ?? ""}`.toUpperCase();
  if (/(EQUIPMENT|MACHIN|PRODUCTION LINE|MANUFACTUR)/.test(corpus)) return "EQUIPMENT";
  return "REFINANCE"; // Priority #1; still explicitly a hypothesis, never borrower intent.
}
function scoreRecord(permit: Record<string, unknown>, parcel: Record<string, unknown>, directMatch: boolean, ownerMatch: boolean) {
  let score = 0.42;
  if (directMatch) score += 0.22;
  if (ownerMatch) score += 0.08;
  if (isCommercial(parcel)) score += 0.10;
  const value = num(parcel.MKT_CUR_VALUE) ?? 0;
  if (value >= 500_000 && value <= 5_000_000) score += 0.08;
  else if (value >= 100_000 && value <= 20_000_000) score += 0.04;
  const amount = num(permit.PERMITAMOUNT) ?? 0;
  if (amount >= 100_000) score += 0.05;
  if (num(permit.LENDERCODE)) score += 0.03;
  return clamp(score, 0, 0.97);
}
function estimateRange(marketValue: number | null) {
  if (!marketValue || marketValue < 100_000) return [null, null] as const;
  return [clamp(Math.round(marketValue * 0.45 / 10_000) * 10_000, 100_000, 20_000_000), clamp(Math.round(marketValue * 0.75 / 10_000) * 10_000, 100_000, 20_000_000)] as const;
}

router.get("/atlas/dashboard", async (_req, res, next) => {
  try {
    const [[opp], [perm], [prop], [latest]] = await Promise.all([
      db.select({ n: count() }).from(atlasOpportunities), db.select({ n: count() }).from(atlasPermits),
      db.select({ n: count() }).from(atlasProperties), db.select().from(atlasIngestRuns).orderBy(desc(atlasIngestRuns.id)).limit(1),
    ]);
    const rows = await db.select().from(atlasOpportunities).orderBy(desc(atlasOpportunities.score)).limit(100);
    const pipelineMap = new Map<string, { value: number; count: number }>();
    for (const r of rows) { const x = pipelineMap.get(r.product) ?? { value: 0, count: 0 }; x.count++; x.value += ((r.estimatedMin ?? 0) + (r.estimatedMax ?? 0)) / 2; pipelineMap.set(r.product, x); }
    const data = GetAtlasDashboardResponse.parse({
      counts: { opportunities: opp?.n ?? 0, permits: perm?.n ?? 0, properties: prop?.n ?? 0, referrals: 0, followUps: 0 },
      pipeline: [...pipelineMap].map(([label, x]) => ({ label, ...x })),
      latestIngest: latest ? { runId: latest.id, seen: latest.seen, written: latest.written, verifiedMatches: latest.verifiedMatches, reviewRequired: latest.reviewRequired, rejected: latest.rejected, promoted: latest.promoted, startedAt: latest.startedAt.toISOString(), finishedAt: latest.finishedAt?.toISOString() ?? null } : null,
      coverage: latest ? { verified: latest.verifiedMatches, reviewRequired: latest.reviewRequired, rejected: latest.rejected } : { verified: 0, reviewRequired: 0, rejected: 0 },
    });
    res.json(data);
  } catch (e) { next(e); }
});

router.get("/atlas/opportunities", async (req, res, next) => {
  try {
    const q = ListAtlasOpportunitiesQueryParams.parse(req.query);
    const filters = [];
    if (q.status) filters.push(eq(atlasOpportunities.status, q.status));
    if (q.product) filters.push(eq(atlasOpportunities.product, q.product));
    if (q.minScore !== undefined) filters.push(gte(atlasOpportunities.score, q.minScore));
    const rows = await db.select().from(atlasOpportunities).where(filters.length ? and(...filters) : undefined).orderBy(desc(atlasOpportunities.score)).limit(q.limit);
    res.json(ListAtlasOpportunitiesResponse.parse(rows.map(r => ({ id: r.id, company: r.company, product: r.product, score: r.score, status: r.status, verificationState: r.verificationState, estimatedMin: r.estimatedMin, estimatedMax: r.estimatedMax, reason: r.reason, location: r.location, propertyType: r.propertyType, marketValue: r.marketValue, signalCount: r.signalCount, updatedAt: r.updatedAt.toISOString() }))));
  } catch (e) { next(e); }
});

router.get("/atlas/referrals", (_req, res) => res.json(ListAtlasReferralsResponse.parse([])));
router.get("/atlas/follow-ups", (_req, res) => res.json(ListAtlasFollowUpsResponse.parse([])));
router.get("/atlas/signals", async (_req, res, next) => {
  try {
    const latest = await db.select().from(atlasIngestRuns).orderBy(desc(atlasIngestRuns.id)).limit(1);
    const signals = latest[0] ? [{ id: latest[0].id, label: "Official-source ingest completed", detail: `${latest[0].seen} permits checked; ${latest[0].verifiedMatches} corroborated parcel matches; ${latest[0].reviewRequired} held for review; ${latest[0].rejected} rejected.`, severity: latest[0].reviewRequired ? "MEDIUM" : "LOW", occurredAt: (latest[0].finishedAt ?? latest[0].startedAt).toISOString() }] : [];
    res.json(ListAtlasSignalsResponse.parse(signals));
  } catch (e) { next(e); }
});

router.post("/atlas/ingest", async (req, res, next) => {
  const input = RunAtlasIngestBody.parse(req.body ?? {});
  const startedAt = new Date();
  try {
    const permits = await fetchRecentPermits(input.limit);
    let written = 0, verifiedMatches = 0, reviewRequired = 0, rejected = 0;
    for (const feature of permits) {
      const p = feature.attributes;
      const permitNo = textValue(p.PERMITNO) ?? `OID-${p.ESRI_OID}`;
      const accountNo = textValue(p.ACCOUNTNO);
      if (!accountNo) { rejected++; continue; }
      const parcels = await findParcelForAccount(accountNo);
      if (parcels.length !== 1) { reviewRequired++; continue; }
      const parcel = parcels[0].attributes;
      const directMatch = exactAccountParcelMatch(accountNo, parcel);
      if (!directMatch) { reviewRequired++; continue; }
      const parcelId = textValue(parcel.PARCELID);
      if (!parcelId) { rejected++; continue; }
      const ownerMatch = ownerCorroborates(textValue(p.OWNERNAME), textValue(parcel.OWNER_NAME));
      const [property] = await db.insert(atlasProperties).values({
        parcelId, parcelNo: textValue(parcel.PARCEL_NO), ownerName: textValue(parcel.OWNER_NAME), siteAddress: textValue(parcel.SITE_FULL_ADDRESS), city: textValue(parcel.SITE_CITY), zip: textValue(parcel.SITE_ZIP5), propertyType: textValue(parcel.SPC_PROP_TYP_DESCR) ?? textValue(parcel.PROP_TYPE_DESCR), acreage: num(parcel.ACREAGE), marketLandValue: num(parcel.MKT_LAND_COM), marketImprovementValue: num(parcel.MKT_IMP_COM), marketValue: num(parcel.MKT_CUR_VALUE), previousMarketValue: num(parcel.MKT_PRV_VAL), yearBuilt: num(parcel.GLA_WEIGHTED_YRBLT) ? Math.round(num(parcel.GLA_WEIGHTED_YRBLT)!) : null, aboveGradeArea: num(parcel.TOTAL_ABOVE_GRADE_AREA) ? Math.round(num(parcel.TOTAL_ABOVE_GRADE_AREA)!) : null, sourceObjectId: textValue(parcel.OBJECTID), sourceUrl: atlasSources.parcel, sourceUpdatedAt: toDate(parcel.LASTUPDATE), raw: parcel,
      }).onConflictDoUpdate({ target: atlasProperties.parcelId, set: { ownerName: textValue(parcel.OWNER_NAME), siteAddress: textValue(parcel.SITE_FULL_ADDRESS), city: textValue(parcel.SITE_CITY), zip: textValue(parcel.SITE_ZIP5), propertyType: textValue(parcel.SPC_PROP_TYP_DESCR) ?? textValue(parcel.PROP_TYPE_DESCR), marketValue: num(parcel.MKT_CUR_VALUE), previousMarketValue: num(parcel.MKT_PRV_VAL), raw: parcel, updatedAt: new Date() } }).returning();
      const verificationState = ownerMatch ? "CORROBORATED" : "VERIFIED_SOURCE_LINK";
      const [permit] = await db.insert(atlasPermits).values({ permitNo, accountNo, permitType: textValue(p.PERMITTYPE), classification: textValue(p.PERMITCLASSIFICATION), permitDate: toDate(p.PERMITDATE), permitAmount: num(p.PERMITAMOUNT), reason: textValue(p.PERMITREASON), reasonDetail: textValue(p.PERMITREASONDETAIL), permitUse: textValue(p.PERMITUSE), status: textValue(p.PERMITSTATUS), ownerName: textValue(p.OWNERNAME), contractorCode: textValue(p.CONTRACTORCODE), lenderCode: textValue(p.LENDERCODE), propertyId: property.id, verificationState, verificationReason: ownerMatch ? "Exact official account/parcel match plus owner-name corroboration" : "Exact official account/parcel match; owner name not used as a fact match", sourceObjectId: textValue(p.ESRI_OID), sourceUrl: atlasSources.permit, raw: p,
      }).onConflictDoUpdate({ target: atlasPermits.permitNo, set: { propertyId: property.id, verificationState, raw: p, updatedAt: new Date() } }).returning();
      written++; verifiedMatches++;
      const score = scoreRecord(p, parcel, directMatch, ownerMatch);
      if (input.promoteVerified && score >= PROMOTION_THRESHOLD && isCommercial(parcel)) {
        const marketValue = num(parcel.MKT_CUR_VALUE); const [estimatedMin, estimatedMax] = estimateRange(marketValue);
        const product = productHypothesis(p, parcel);
        const company = textValue(parcel.OWNER_NAME) ?? textValue(p.OWNERNAME) ?? "Unknown property owner";
        const location = [textValue(parcel.SITE_CITY), "UT"].filter(Boolean).join(", ");
        const reason = `${product.replaceAll("_", " ")} is an Atlas hypothesis based on a corroborated Utah County permit-to-parcel link, commercial property context, and recent capital activity. Borrower intent is not confirmed.`;
        const existing = await db.select({ id: atlasOpportunities.id }).from(atlasOpportunities).where(eq(atlasOpportunities.permitId, permit.id)).limit(1);
        if (!existing.length) await db.insert(atlasOpportunities).values({ permitId: permit.id, propertyId: property.id, company, product, score, verificationState, estimatedMin, estimatedMax, reason, location, propertyType: textValue(parcel.SPC_PROP_TYP_DESCR) ?? textValue(parcel.PROP_TYPE_DESCR), marketValue, signalCount: ownerMatch ? 4 : 3 });
      }
    }
    const finishedAt = new Date();
    const [run] = await db.insert(atlasIngestRuns).values({ seen: permits.length, written, verifiedMatches, reviewRequired, rejected, promoted: input.promoteVerified, startedAt, finishedAt, notes: `Official Utah County sources only. Parcel: ${atlasSources.parcel}; Permit: ${atlasSources.permit}` }).returning();
    res.json(RunAtlasIngestResponse.parse({ runId: run.id, seen: permits.length, written, verifiedMatches, reviewRequired, rejected, promoted: input.promoteVerified, startedAt: startedAt.toISOString(), finishedAt: finishedAt.toISOString() }));
  } catch (e) { req.log.error({ err: e }, "Atlas official-source ingest failed"); next(e); }
});

export default router;
