import argparse, json
from atlas.ingest import ingest_utah_county

p=argparse.ArgumentParser(description="Controlled Utah County Atlas ingest")
p.add_argument("--permits",type=int,default=100)
p.add_argument("--since-hours",type=int,default=None)
g=p.add_mutually_exclusive_group()
g.add_argument("--qa-only",action="store_true")
g.add_argument("--promote-verified",action="store_true")
a=p.parse_args()
print(json.dumps(ingest_utah_county(limit=a.permits,since_hours=a.since_hours,promote_verified=a.promote_verified),indent=2))
