# Atlas Lending V1 — Utah County

Working MVP reconstructed from the Atlas Developer Handoff and the Utah County lending requirements.

## Locked V1 scope
- Geography: Utah County, Utah
- Sweet spot: $500k–$5M
- Absolute range: $100k–$20M
- Product priority: Refinance, Equipment, Investor CRE, Owner-occupied CRE, Working-capital LOC
- CRM: Atlas
- Morning Brief: Top 10 Lending Opportunities, Top 10 Referral Opportunities, Significant Signal Changes, Follow-ups Due
- Decision threshold: 0.78

## Integrity model
Atlas stores source facts separately from Atlas inferences. Every source fact retains source system, source record ID, acquisition time, raw payload hash and verification state. Missing data remains UNKNOWN. Entity matches below the automatic threshold are held for review and are not promoted to the CRM.

Verification states: VERIFIED_SOURCE, CORROBORATED, REVIEW_REQUIRED, INFERRED, REJECTED.

## Official V1 sources
1. Utah County Assessor parcel layer
   https://maps.utahcounty.gov/arcgis/rest/services/Pictometry/POL_Assr_TaxParcel/MapServer/0
2. Utah County Assessor building permit table
   https://maps200.utahcounty.gov/arcgis/rest/services/Assessor/Building_Permits/MapServer/1

## Run locally / Replit
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn atlas.main:app --host 0.0.0.0 --port 8000
```
Open `/` for the dashboard.

## First live controlled ingest
Do not bulk-promote records on the first run. Run:
```bash
python scripts/live_ingest.py --permits 100 --qa-only
```
This retrieves 100 recent permit records, attempts parcel matches, writes source lineage and validation results, but leaves review-required records out of the active CRM opportunity queue.

After manual QA:
```bash
python scripts/live_ingest.py --permits 100 --promote-verified
```

## Tests
```bash
pytest -q
```

## Deployment schedule
Once the first controlled batch is audited, schedule `python scripts/live_ingest.py --since-hours 48 --promote-verified` daily. The job is idempotent by source + source record ID.
