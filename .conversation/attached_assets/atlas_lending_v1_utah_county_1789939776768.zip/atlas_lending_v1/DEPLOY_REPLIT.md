# Replit deployment
1. Create a new Python Repl and upload this project ZIP.
2. Set Run command: `uvicorn atlas.main:app --host 0.0.0.0 --port 8000`
3. Install: `pip install -r requirements.txt`
4. Start the app and verify `/health`.
5. Run the first controlled batch in Shell: `python scripts/live_ingest.py --permits 100 --qa-only`
6. Review the ingest counts. Do not promote review-required matches.
7. After QA, run `python scripts/live_ingest.py --permits 100 --promote-verified`.
8. Only after the pilot passes, schedule the daily command: `python scripts/live_ingest.py --since-hours 48 --promote-verified`.

Important: Replit/network access must be able to reach the two official Utah County ArcGIS hosts. If one host blocks cloud traffic, use the county downloadable snapshot as the next connector rather than a third-party mirror.
