from __future__ import annotations
import re
from datetime import datetime, timezone

CORP_WORDS = {"LLC","LC","INC","INCORPORATED","CORP","CORPORATION","LTD","LP","LLP","PLLC","CO","COMPANY"}

def clean_text(v):
    if v is None: return None
    s = re.sub(r"\s+", " ", str(v)).strip()
    return s or None

def normalize_name(v: str | None) -> str:
    if not v: return ""
    s = re.sub(r"[^A-Z0-9 ]", " ", v.upper())
    toks = [t for t in s.split() if t not in CORP_WORDS]
    return " ".join(toks)

def parse_esri_date(v):
    if v in (None, ""): return None
    if isinstance(v, (int, float)):
        return datetime.fromtimestamp(v / 1000, tz=timezone.utc)
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        return None

def pick(d: dict, *keys):
    upper = {str(k).upper(): v for k, v in d.items()}
    for k in keys:
        target=k.upper()
        if target in upper and upper[target] not in (None, ""):
            return upper[target]
        # Joined ArcGIS layers can return qualified keys such as parcel_point.PARCELID.
        for actual, value in upper.items():
            if actual.endswith("."+target) and value not in (None, ""):
                return value
    return None

def permit_record(a: dict) -> dict:
    return {
        "source_record_id": str(pick(a,"SEQID","ESRI_OID","PERMITNO") or ""),
        "permit_no": clean_text(pick(a,"PERMITNO","LOCALPERMITNO")),
        "account_no": clean_text(pick(a,"ACCOUNTNO","ACCOUNT_NO")),
        "parcel_id": clean_text(pick(a,"PARCELID","PARCEL_ID_LABEL","PARCELID_LABEL")),
        "owner_name": clean_text(pick(a,"OWNERNAME","OWNER_NAME")),
        "permit_date": parse_esri_date(pick(a,"PERMITDATE")),
        "permit_amount": _num(pick(a,"PERMITAMOUNT")),
        "permit_type": clean_text(pick(a,"PERMITTYPE")),
        "classification": clean_text(pick(a,"PERMITCLASSIFICATION")),
        "reason": clean_text(pick(a,"PERMITREASONDETAIL","PERMITREASON")),
        "use": clean_text(pick(a,"PERMITUSE")),
        "status": clean_text(pick(a,"PERMITSTATUS")),
        "lender_code": clean_text(pick(a,"LENDERCODE")),
    }

def parcel_record(a: dict) -> dict:
    return {
        "parcel_id": clean_text(pick(a,"PARCELID","PARCEL_ID_LABEL","PARCELID_LABEL","PARCEL_NO")),
        "account_no": clean_text(pick(a,"ACCOUNT_NO","ACCOUNTNO","SERIAL")),
        "owner_name": clean_text(pick(a,"OWNER_NAME","CNVYNAME")),
        "site_address": clean_text(pick(a,"SITE_FULL_ADDRESS","SITE_ADDRESS","ADDRESS")),
        "city": clean_text(pick(a,"SITE_CITY","TAX_CITY","CITY")),
        "property_type": clean_text(pick(a,"SPC_PROP_TYP_DESCR","PROP_TYPE_DESCR","USE_CODE_DESCR_1")),
        "market_value": _num(pick(a,"MKT_CUR_VALUE","TOTAL_MKT_VALUE","TOTAL_MARKET_VALUE","MARKET_VALUE","CURR_MKT_VALUE")),
        "commercial_land_value": _num(pick(a,"MKT_LAND_COM","COMM_LAND_VALUE","COMMERCIAL_LAND_VALUE")),
        "commercial_improvement_value": _num(pick(a,"MKT_IMP_COM","COMM_IMP_VALUE","COMMERCIAL_IMPROVEMENT_VALUE")),
        "year_built": _int(pick(a,"YEAR_BUILT_1","YEARBLT_RES","YEAR_BUILT")),
    }

def _num(v):
    try: return float(v) if v not in (None,"") else None
    except (TypeError,ValueError): return None

def _int(v):
    try: return int(float(v)) if v not in (None,"") else None
    except (TypeError,ValueError): return None
