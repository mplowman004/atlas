from __future__ import annotations
from difflib import SequenceMatcher
from .normalize import normalize_name

def name_similarity(a: str | None, b: str | None) -> float:
    aa, bb = normalize_name(a), normalize_name(b)
    if not aa or not bb: return 0.0
    if aa == bb: return 1.0
    return SequenceMatcher(None, aa, bb).ratio()

def match_permit_to_parcel(permit: dict, parcels: list[dict]) -> tuple[dict | None, float, str]:
    if not parcels:
        return None, 0.0, "NO_CANDIDATE"
    p_parcel = (permit.get("parcel_id") or "").strip()
    if p_parcel:
        exact = [p for p in parcels if (p.get("parcel_id") or "").strip() == p_parcel]
        if len(exact) == 1:
            sim = name_similarity(permit.get("owner_name"), exact[0].get("owner_name"))
            # Same authoritative county joined layer supplies parcel ID; owner agreement corroborates it.
            return exact[0], 0.995 if sim >= .70 else 0.96, "COUNTY_JOINED_PARCEL_ID"
    p_account = (permit.get("account_no") or "").strip()
    if p_account:
        exact = [p for p in parcels if (p.get("account_no") or "").strip() == p_account]
        if len(exact) == 1:
            sim = name_similarity(permit.get("owner_name"), exact[0].get("owner_name"))
            return exact[0], 0.99 if sim >= .70 else 0.94, "ACCOUNT_EXACT"
        if len(exact) > 1:
            ranked = sorted(exact, key=lambda x: name_similarity(permit.get("owner_name"), x.get("owner_name")), reverse=True)
            sim = name_similarity(permit.get("owner_name"), ranked[0].get("owner_name"))
            return ranked[0], min(.98, .90 + .08 * sim), "ACCOUNT_PLUS_OWNER"
    ranked = sorted(parcels, key=lambda x: name_similarity(permit.get("owner_name"), x.get("owner_name")), reverse=True)
    sim = name_similarity(permit.get("owner_name"), ranked[0].get("owner_name"))
    if sim >= .96: return ranked[0], .90, "OWNER_EXACT_NORMALIZED"
    if sim >= .88: return ranked[0], .80, "OWNER_STRONG"
    return None, sim, "REVIEW_REQUIRED"

def verification_state(confidence: float) -> str:
    if confidence >= .94: return "CORROBORATED"
    if confidence >= .88: return "REVIEW_REQUIRED"
    return "REVIEW_REQUIRED"
