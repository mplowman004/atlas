from __future__ import annotations
from datetime import datetime, timezone

WEIGHTS={"signal":.30,"contact":.18,"target":.18,"freshness":.12,"economics":.08,"provenance":.08,"entity":.06}

def score_opportunity(permit: dict, prop: dict | None, signals: list[dict], match_confidence: float) -> tuple[float,dict]:
    signal=max([s["strength"] for s in signals], default=.35)
    # No contact provider in free-data V1: do not invent readiness.
    contact=.15
    amount=permit.get("permit_amount") or 0
    mv=(prop or {}).get("market_value") or 0
    basis=max(amount,mv)
    target=1.0 if 500000 <= basis <= 5_000_000 else (.72 if 100000 <= basis <= 20_000_000 else .35)
    d=permit.get("permit_date")
    days=(datetime.now(timezone.utc)-d).days if d else 999
    freshness=1.0 if days<=30 else .85 if days<=90 else .65 if days<=180 else .4
    economics=.95  # free official source
    provenance=1.0 # authoritative source record; inference is stored separately
    entity=max(.1,min(1.0,match_confidence))
    parts={"signal":signal,"contact":contact,"target":target,"freshness":freshness,"economics":economics,"provenance":provenance,"entity":entity}
    total=sum(parts[k]*WEIGHTS[k] for k in WEIGHTS)
    return round(total,4),parts
