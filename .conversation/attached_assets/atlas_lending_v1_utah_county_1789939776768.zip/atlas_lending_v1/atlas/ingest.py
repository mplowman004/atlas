from __future__ import annotations
import hashlib, json
from datetime import datetime, timezone
from sqlalchemy import select
from .db import SessionLocal, init_db
from .models import SourceRecord, Property, Permit, Opportunity, IngestRun
from .connectors.utah_county import UtahCountyConnector, PARCEL_URL, PERMIT_URL
from .normalize import permit_record, parcel_record
from .validation import match_permit_to_parcel
from .signals import derive_signals, product_hypothesis
from .scoring import score_opportunity
from .config import settings

def _json(obj):
    return json.dumps(obj, sort_keys=True, default=str, separators=(",",":"))

def _hash(obj):
    return hashlib.sha256(_json(obj).encode()).hexdigest()

def _upsert_source(db, system, rid, url, raw):
    row=db.scalar(select(SourceRecord).where(SourceRecord.source_system==system,SourceRecord.source_record_id==rid))
    if row:
        row.raw_json=_json(raw); row.payload_hash=_hash(raw); row.acquired_at=datetime.now(timezone.utc)
        return row
    row=SourceRecord(source_system=system,source_record_id=rid,source_url=url,payload_hash=_hash(raw),raw_json=_json(raw),verification_state="VERIFIED_SOURCE")
    db.add(row); db.flush(); return row

def ingest_utah_county(limit=100, since_hours=None, promote_verified=False, connector=None):
    init_db(); connector=connector or UtahCountyConnector()
    with SessionLocal() as db:
        run=IngestRun(source="UTAH_COUNTY_PERMITS"); db.add(run); db.flush()
        try:
            raw_permits=connector.recent_permits(limit=limit,since_hours=since_hours)
            run.records_seen=len(raw_permits)
            for raw in raw_permits:
                p=permit_record(raw)
                if not p["permit_no"] or not p["source_record_id"]:
                    run.rejected += 1; continue
                src=_upsert_source(db,"UTAH_COUNTY_ASSESSOR_PERMIT",p["source_record_id"],PERMIT_URL,raw)
                existing=db.scalar(select(Permit).where(Permit.permit_no==p["permit_no"]))
                if existing:
                    continue
                candidates=[]
                raw_candidates=[]
                if p.get("parcel_id"):
                    try:
                        raw_candidates=connector.parcel_by_id(p["parcel_id"])
                        candidates=[parcel_record(x) for x in raw_candidates]
                    except Exception: candidates=[]
                if not candidates and p.get("owner_name"):
                    try:
                        raw_candidates=connector.parcels_by_owner(p["owner_name"])
                        candidates=[parcel_record(x) for x in raw_candidates]
                    except Exception: candidates=[]
                matched, conf, method=match_permit_to_parcel(p,candidates)
                prop_row=None
                if matched:
                    parcel_rid=matched.get("parcel_id") or f"owner:{matched.get('owner_name')}"
                    raw_match=next((r for r in raw_candidates if parcel_record(r).get("parcel_id")==matched.get("parcel_id")), matched)
                    psrc=_upsert_source(db,"UTAH_COUNTY_ASSESSOR_PARCEL",str(parcel_rid),PARCEL_URL,raw_match)
                    if matched.get("parcel_id"):
                        prop_row=db.scalar(select(Property).where(Property.parcel_id==matched["parcel_id"]))
                    if not prop_row:
                        prop_row=Property(**matched,last_source_id=psrc.id,verified=conf>=.94)
                        db.add(prop_row); db.flush()
                permit_row=Permit(permit_no=p["permit_no"],account_no=p.get("account_no"),owner_name=p.get("owner_name"),permit_date=p.get("permit_date"),permit_amount=p.get("permit_amount"),permit_type=p.get("permit_type"),classification=p.get("classification"),reason=p.get("reason"),use=p.get("use"),status=p.get("status"),lender_code=p.get("lender_code"),property_id=prop_row.id if prop_row else None,source_id=src.id,match_confidence=conf,match_method=method)
                db.add(permit_row); db.flush(); run.records_written += 1
                if conf>=.94: run.verified_matches += 1
                else: run.review_required += 1
                prop_dict=matched if matched else None
                signals=derive_signals(p,prop_dict)
                score,parts=score_opportunity(p,prop_dict,signals,conf)
                product,lo,hi,reason=product_hypothesis(p,prop_dict,signals)
                if promote_verified and conf>=.94 and score>=settings.min_score:
                    db.add(Opportunity(property_id=prop_row.id if prop_row else None,permit_id=permit_row.id,company_name=p.get("owner_name") or "UNKNOWN",primary_product=product,estimated_min=lo,estimated_max=hi,score=score,verification_state="INFERRED",reason=reason+" Score components: "+_json(parts)))
            run.finished_at=datetime.now(timezone.utc)
            db.commit()
            return {"run_id":run.id,"seen":run.records_seen,"written":run.records_written,"verified_matches":run.verified_matches,"review_required":run.review_required,"rejected":run.rejected,"promoted":promote_verified}
        except Exception as e:
            run.finished_at=datetime.now(timezone.utc); run.notes=f"FAILED: {type(e).__name__}: {e}"; db.commit(); raise
