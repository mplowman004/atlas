from __future__ import annotations
from datetime import datetime, timezone

def derive_signals(permit: dict, prop: dict | None) -> list[dict]:
    out=[]
    amount=permit.get("permit_amount") or 0
    text=" ".join(filter(None,[permit.get("permit_type"),permit.get("classification"),permit.get("reason"),permit.get("use")])).lower()
    if amount >= 250000:
        out.append({"name":"MATERIAL_CAPITAL_PROJECT","strength":min(1.0,.55 + amount/5_000_000)})
    if amount >= 1_000_000:
        out.append({"name":"HIGH_VALUE_CAPITAL_PROJECT","strength":min(1.0,.72 + amount/10_000_000)})
    if any(k in text for k in ["addition","expand","expansion","new commercial","warehouse","office","industrial"]):
        out.append({"name":"BUSINESS_EXPANSION_CAPITAL","strength":.88})
    if any(k in text for k in ["remodel","renovation","tenant improvement","improvement"]):
        out.append({"name":"CRE_IMPROVEMENT_FINANCING","strength":.82})
    if any(k in text for k in ["commercial","warehouse","industrial","office","retail","multifamily","apartment"]):
        out.append({"name":"CRE_CONSTRUCTION_FINANCING","strength":.78})
    if permit.get("lender_code"):
        out.append({"name":"EXISTING_LENDER_CODE_PRESENT","strength":.75})
    if prop and prop.get("market_value") and prop["market_value"] >= 500000:
        out.append({"name":"CRE_VALUE_IN_TARGET_RANGE","strength":.78})
    return out

def product_hypothesis(permit: dict, prop: dict | None, signals: list[dict]) -> tuple[str,float|None,float|None,str]:
    amount=permit.get("permit_amount") or 0
    mv=(prop or {}).get("market_value") or 0
    names={s["name"] for s in signals}
    # Product priority follows user's locked ordering. These are hypotheses, never borrower intent.
    if mv >= 500000 and (permit.get("lender_code") or "CRE_VALUE_IN_TARGET_RANGE" in names):
        lo=max(100000, min(20_000_000, mv*.45))
        hi=max(lo, min(20_000_000, mv*.75))
        return "REFINANCE",lo,hi,"Established CRE asset with current capital activity; refinance is a conversation hypothesis, not confirmed intent."
    if amount >= 100000 and any(k in " ".join(filter(None,[permit.get('reason'),permit.get('use'),permit.get('permit_type')])).lower() for k in ["equipment","manufactur","industrial"]):
        return "EQUIPMENT",max(100000,amount*.4),min(5_000_000,max(100000,amount)),"Capital project may create equipment financing need; unconfirmed."
    if mv >= 500000:
        return "INVESTOR_CRE",max(100000,mv*.45),min(20_000_000,mv*.75),"Commercial property value and activity support an investor CRE conversation hypothesis."
    if amount >= 100000:
        return "OWNER_OCCUPIED_CRE",max(100000,amount*.6),min(5_000_000,max(100000,amount*1.2)),"Recent property investment may support owner-occupied CRE financing discussion."
    return "WORKING_CAP_LOC",100000,min(1_000_000,max(100000,amount*.5 if amount else 250000)),"Recent operating/capital activity may create working-capital needs; unconfirmed."
