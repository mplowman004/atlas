from __future__ import annotations
import httpx

class ArcGISClient:
    def __init__(self, timeout: float = 45.0):
        self.timeout = timeout

    def query(self, layer_url: str, *, where: str = "1=1", out_fields: str = "*", limit: int = 100,
              offset: int = 0, order_by: str | None = None, return_geometry: bool = False) -> list[dict]:
        params = {
            "where": where,
            "outFields": out_fields,
            "returnGeometry": str(return_geometry).lower(),
            "resultRecordCount": limit,
            "resultOffset": offset,
            "f": "json",
        }
        if order_by:
            params["orderByFields"] = order_by
        with httpx.Client(timeout=self.timeout, follow_redirects=True) as client:
            r = client.get(f"{layer_url.rstrip('/')}/query", params=params)
            r.raise_for_status()
            data = r.json()
        if "error" in data:
            raise RuntimeError(f"ArcGIS error: {data['error']}")
        return [f.get("attributes", {}) for f in data.get("features", [])]
