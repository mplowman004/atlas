from __future__ import annotations
from datetime import datetime, timezone
from .arcgis import ArcGISClient

PARCEL_URL = "https://maps.utahcounty.gov/arcgis/rest/services/Pictometry/POL_Assr_TaxParcel/MapServer/0"
# Layer 0 is the stronger source: Utah County publishes a parcel-point layer already joined
# to the Assessor building-permit table. It exposes parcel_point.PARCELID alongside permit data.
PERMIT_URL = "https://maps200.utahcounty.gov/arcgis/rest/services/Assessor/Building_Permits/MapServer/0"

PERMIT_FIELDS = "*"
PARCEL_FIELDS = "*"

class UtahCountyConnector:
    def __init__(self, client: ArcGISClient | None = None):
        self.client = client or ArcGISClient()

    def recent_permits(self, limit: int = 100, since_hours: int | None = None) -> list[dict]:
        where = "1=1"
        # Qualified joined-field syntax varies by ArcGIS service version. For the initial
        # controlled batch, order by date and avoid a date WHERE unless explicitly requested.
        if since_hours:
            cutoff = datetime.fromtimestamp(datetime.now(timezone.utc).timestamp()-since_hours*3600, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
            where = f"a_Building_Permits.PERMITDATE >= DATE '{cutoff}'"
        try:
            return self.client.query(PERMIT_URL, where=where, out_fields=PERMIT_FIELDS,
                                     limit=limit, order_by="a_Building_Permits.PERMITDATE DESC", return_geometry=False)
        except Exception:
            # This joined layer advertises limited advanced-query support. Retry without orderBy.
            return self.client.query(PERMIT_URL, where=where, out_fields=PERMIT_FIELDS,
                                     limit=limit, return_geometry=False)

    def parcel_by_id(self, parcel_id: str, limit: int = 5) -> list[dict]:
        safe = str(parcel_id).replace("'", "''")
        return self.client.query(PARCEL_URL, where=f"PARCELID='{safe}'", out_fields=PARCEL_FIELDS,
                                 limit=limit, return_geometry=False)

    def parcels_by_owner(self, owner_name: str, limit: int = 25) -> list[dict]:
        safe = owner_name.replace("'", "''")
        return self.client.query(PARCEL_URL, where=f"OWNER_NAME='{safe}'", out_fields=PARCEL_FIELDS,
                                 limit=limit, return_geometry=False)
