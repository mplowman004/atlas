from __future__ import annotations
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy import select, func
from .db import init_db, SessionLocal
from .models import Opportunity, Permit, Property, IngestRun
from .ingest import ingest_utah_county

app=FastAPI(title="Atlas Lending V1",version="1.0.0")

@app.on_event("startup")
def startup(): init_db()

@app.get("/health")
def health(): return {"status":"ok","app":"Atlas Lending V1","geography":"Utah County"}

@app.get("/api/dashboard")
def dashboard():
    with SessionLocal() as db:
        opps=db.scalars(select(Opportunity).order_by(Opportunity.score.desc()).limit(10)).all()
        latest=db.scalar(select(IngestRun).order_by(IngestRun.id.desc()).limit(1))
        return {"top_opportunities":[{"id":o.id,"company":o.company_name,"product":o.primary_product,"score":o.score,"estimated_min":o.estimated_min,"estimated_max":o.estimated_max,"reason":o.reason,"status":o.status} for o in opps],"counts":{"opportunities":db.scalar(select(func.count()).select_from(Opportunity)),"permits":db.scalar(select(func.count()).select_from(Permit)),"properties":db.scalar(select(func.count()).select_from(Property))},"latest_ingest":None if not latest else {"id":latest.id,"seen":latest.records_seen,"written":latest.records_written,"verified_matches":latest.verified_matches,"review_required":latest.review_required,"rejected":latest.rejected,"notes":latest.notes}}

@app.post("/api/ingest/utah-county")
def ingest(limit:int=100,promote_verified:bool=False):
    if limit<1 or limit>1000: raise HTTPException(400,"limit must be 1..1000")
    try: return ingest_utah_county(limit=limit,promote_verified=promote_verified)
    except Exception as e: raise HTTPException(502,f"Official source fetch failed: {e}")

@app.get("/",response_class=HTMLResponse)
def home():
    return HTMLResponse('''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Atlas Lending V1</title><style>body{font-family:Inter,system-ui;background:#0b1020;color:#eef2ff;margin:0}.wrap{max-width:1100px;margin:auto;padding:36px}.top{display:flex;justify-content:space-between;align-items:end}.muted{color:#9aa6c2}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:24px 0}.card{background:#131a2d;border:1px solid #26314d;border-radius:14px;padding:18px}.big{font-size:30px;font-weight:800}.opp{margin:12px 0;padding:18px;background:#131a2d;border-radius:14px;border:1px solid #26314d}.score{float:right;font-size:22px;font-weight:800}.pill{display:inline-block;background:#243252;padding:5px 9px;border-radius:999px;font-size:12px}.empty{padding:35px;text-align:center;border:1px dashed #39445f;border-radius:14px}.warn{background:#332814;border:1px solid #725719;padding:12px;border-radius:10px;color:#ffe6a3}@media(max-width:700px){.grid{grid-template-columns:1fr}}</style></head><body><div class="wrap"><div class="top"><div><h1>ATLAS — Utah County</h1><div class="muted">Commercial Lending Intelligence • V1</div></div><div class="pill">Decision threshold 0.78</div></div><div class="warn">Source facts and Atlas inferences are stored separately. Only corroborated parcel/permit matches can be promoted.</div><div class="grid"><div class="card"><div class="muted">Opportunities</div><div id="opps" class="big">—</div></div><div class="card"><div class="muted">Permits staged</div><div id="permits" class="big">—</div></div><div class="card"><div class="muted">Properties matched</div><div id="props" class="big">—</div></div></div><h2>Top lending opportunities</h2><div id="list" class="empty">No promoted opportunities yet. Run the controlled Utah County ingest after deployment.</div></div><script>fetch('/api/dashboard').then(r=>r.json()).then(d=>{opps.textContent=d.counts.opportunities;permits.textContent=d.counts.permits;props.textContent=d.counts.properties;if(d.top_opportunities.length){list.className='';list.innerHTML=d.top_opportunities.map(o=>`<div class="opp"><span class="score">${Math.round(o.score*100)}</span><b>${o.company}</b><br><span class="pill">${o.product}</span><p>${o.reason}</p><span class="muted">Estimated conversation range: ${o.estimated_min?('$'+Math.round(o.estimated_min).toLocaleString()):'Unknown'} – ${o.estimated_max?('$'+Math.round(o.estimated_max).toLocaleString()):'Unknown'}</span></div>`).join('')}})</script></body></html>''')
