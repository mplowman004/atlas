import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    db_url: str = os.getenv("ATLAS_DB_URL", "sqlite:///./data/atlas.db")
    min_score: float = float(os.getenv("ATLAS_MIN_SCORE", "0.78"))
    qa_required: bool = os.getenv("ATLAS_QA_REQUIRED", "true").lower() == "true"
    geography: str = os.getenv("ATLAS_GEOGRAPHY", "Utah County, Utah")

settings = Settings()
