from datetime import datetime, timezone
from sqlalchemy import String, Float, DateTime, Text, Boolean, ForeignKey, Integer, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

def utcnow():
    return datetime.now(timezone.utc)

class SourceRecord(Base):
    __tablename__ = "source_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    source_system: Mapped[str] = mapped_column(String(120), index=True)
    source_record_id: Mapped[str] = mapped_column(String(160), index=True)
    source_url: Mapped[str] = mapped_column(Text)
    acquired_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    payload_hash: Mapped[str] = mapped_column(String(64))
    verification_state: Mapped[str] = mapped_column(String(32), default="VERIFIED_SOURCE")
    raw_json: Mapped[str] = mapped_column(Text)
    __table_args__ = (UniqueConstraint("source_system", "source_record_id", name="uq_source_record"),)

class Property(Base):
    __tablename__ = "properties"
    id: Mapped[int] = mapped_column(primary_key=True)
    parcel_id: Mapped[str | None] = mapped_column(String(40), unique=True, nullable=True, index=True)
    account_no: Mapped[str | None] = mapped_column(String(40), index=True)
    owner_name: Mapped[str | None] = mapped_column(String(240), index=True)
    site_address: Mapped[str | None] = mapped_column(String(400), index=True)
    city: Mapped[str | None] = mapped_column(String(120))
    property_type: Mapped[str | None] = mapped_column(String(160))
    market_value: Mapped[float | None] = mapped_column(Float)
    commercial_land_value: Mapped[float | None] = mapped_column(Float)
    commercial_improvement_value: Mapped[float | None] = mapped_column(Float)
    year_built: Mapped[int | None] = mapped_column(Integer)
    last_source_id: Mapped[int | None] = mapped_column(ForeignKey("source_records.id"))
    verified: Mapped[bool] = mapped_column(Boolean, default=False)

class Permit(Base):
    __tablename__ = "permits"
    id: Mapped[int] = mapped_column(primary_key=True)
    permit_no: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    account_no: Mapped[str | None] = mapped_column(String(40), index=True)
    owner_name: Mapped[str | None] = mapped_column(String(240), index=True)
    permit_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    permit_amount: Mapped[float | None] = mapped_column(Float)
    permit_type: Mapped[str | None] = mapped_column(String(160))
    classification: Mapped[str | None] = mapped_column(String(160))
    reason: Mapped[str | None] = mapped_column(Text)
    use: Mapped[str | None] = mapped_column(String(160))
    status: Mapped[str | None] = mapped_column(String(100))
    lender_code: Mapped[str | None] = mapped_column(String(80))
    property_id: Mapped[int | None] = mapped_column(ForeignKey("properties.id"))
    source_id: Mapped[int] = mapped_column(ForeignKey("source_records.id"))
    match_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    match_method: Mapped[str | None] = mapped_column(String(120))
    property = relationship("Property")

class Opportunity(Base):
    __tablename__ = "opportunities"
    id: Mapped[int] = mapped_column(primary_key=True)
    property_id: Mapped[int | None] = mapped_column(ForeignKey("properties.id"))
    permit_id: Mapped[int | None] = mapped_column(ForeignKey("permits.id"))
    company_name: Mapped[str] = mapped_column(String(240), index=True)
    primary_product: Mapped[str] = mapped_column(String(80))
    estimated_min: Mapped[float | None] = mapped_column(Float)
    estimated_max: Mapped[float | None] = mapped_column(Float)
    score: Mapped[float] = mapped_column(Float, index=True)
    status: Mapped[str] = mapped_column(String(60), default="NEW")
    verification_state: Mapped[str] = mapped_column(String(32), default="INFERRED")
    reason: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    follow_up_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    property = relationship("Property")
    permit = relationship("Permit")

class IngestRun(Base):
    __tablename__ = "ingest_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    source: Mapped[str] = mapped_column(String(120))
    records_seen: Mapped[int] = mapped_column(Integer, default=0)
    records_written: Mapped[int] = mapped_column(Integer, default=0)
    verified_matches: Mapped[int] = mapped_column(Integer, default=0)
    review_required: Mapped[int] = mapped_column(Integer, default=0)
    rejected: Mapped[int] = mapped_column(Integer, default=0)
    notes: Mapped[str | None] = mapped_column(Text)
