from atlas.normalize import permit_record, parcel_record, normalize_name
from atlas.validation import match_permit_to_parcel
from atlas.signals import derive_signals, product_hypothesis
from atlas.scoring import score_opportunity

PERMIT={"SEQID":"abc-1","PERMITNO":"P-100","ACCOUNTNO":"A-1","parcel_point.PARCELID":"12:345:0001","PERMITDATE":1760000000000,"PERMITAMOUNT":650000,"PERMITTYPE":"Commercial Remodel","PERMITCLASSIFICATION":"Commercial","PERMITREASON":"Warehouse expansion","PERMITUSE":"Industrial","LENDERCODE":123,"PERMITSTATUS":"Issued","OWNERNAME":"Wasatch Example Holdings LLC"}
PARCEL={"PARCELID":"12:345:0001","ACCOUNT_NO":"A-1","OWNER_NAME":"WASATCH EXAMPLE HOLDINGS LLC","SITE_FULL_ADDRESS":"100 TEST ST, PROVO, UT 84601","TAX_CITY":"PROVO","PROP_TYPE_DESCR":"Commercial","TOTAL_MKT_VALUE":3200000,"COMM_LAND_VALUE":900000,"COMM_IMP_VALUE":2300000,"YEAR_BUILT_1":2008}

def test_normalize_and_match():
    p=permit_record(PERMIT); q=parcel_record(PARCEL)
    assert normalize_name(p["owner_name"])=="WASATCH EXAMPLE HOLDINGS"
    match,conf,method=match_permit_to_parcel(p,[q])
    assert match==q and conf>=.94 and method=="COUNTY_JOINED_PARCEL_ID"

def test_signals_and_scoring():
    p=permit_record(PERMIT); q=parcel_record(PARCEL)
    sig=derive_signals(p,q)
    names={x["name"] for x in sig}
    assert "BUSINESS_EXPANSION_CAPITAL" in names
    assert "EXISTING_LENDER_CODE_PRESENT" in names
    product,lo,hi,reason=product_hypothesis(p,q,sig)
    assert product=="REFINANCE" and 100000<=lo<=hi<=20000000
    score,parts=score_opportunity(p,q,sig,.99)
    assert 0<=score<=1 and parts["provenance"]==1.0
