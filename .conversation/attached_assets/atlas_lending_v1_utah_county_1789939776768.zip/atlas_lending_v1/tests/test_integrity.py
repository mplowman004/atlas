from atlas.validation import match_permit_to_parcel

def test_ambiguous_owner_is_not_verified():
    permit={"account_no":None,"owner_name":"ABC Holdings"}
    parcels=[{"account_no":None,"owner_name":"ABC Property Group"},{"account_no":None,"owner_name":"XYZ LLC"}]
    match,conf,method=match_permit_to_parcel(permit,parcels)
    assert match is None
    assert method=="REVIEW_REQUIRED"
